from _gdbm import *
